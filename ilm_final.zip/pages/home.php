<div id="page-home" class="page">
    <section class="hero">
        <div class="hero-content container">
            <h1>ইলমের আলোয় <span>আলোকিত</span> জীবন</h1>
            <p>খাঁটি ও মানসম্পন্ন ইসলামি বইয়ের সর্বোচ্চ সংগ্রহ শুধুই ইলম লাইব্রেরিতে। জ্ঞানের দ্বার খুলুন আজই।</p>
            <div class="hero-btns">
                <a href="?page=shop" class="btn-hero btn-hero-primary" data-page="shop">
                    <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                    বই স্টোরে যান
                </a>
                <a href="?page=about" class="btn-hero btn-hero-outline" data-page="about">আমাদের সম্পর্কে</a>
            </div>
            <div class="hero-stats">
                <div class="stat-item"><div class="stat-num" id="statBooks">...</div><div class="stat-lbl">টি বই</div></div>
                <div class="stat-item"><div class="stat-num">৫০০+</div><div class="stat-lbl">সন্তুষ্ট পাঠক</div></div>
                <div class="stat-item"><div class="stat-num">১০০%</div><div class="stat-lbl">বিশ্বস্ত</div></div>
            </div>
        </div>
    </section>
    <div class="container">
        <div class="home-features">
            <div class="feat-card">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
                <h3>১০০% নির্ভরযোগ্য</h3>
                <p>প্রতিটি বই যাচাই করা ও বিশ্বস্ত সূত্র থেকে সংগ্রহ করা।</p>
            </div>
            <div class="feat-card">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                <h3>দ্রুত ডেলিভারি</h3>
                <p>সারাদেশে দ্রুত ও নিরাপদ ডেলিভারি সেবা।</p>
            </div>
            <div class="feat-card">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                <h3>সেরা মূল্য</h3>
                <p>প্রিমিয়াম মানের বই সবচেয়ে সাশ্রয়ী দামে।</p>
            </div>
        </div>

        <div class="featured-section" id="homeFeaturedSection" style="display:none">
            <h2 class="section-title">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="var(--accent)" stroke="var(--accent)" stroke-width="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                ফিচার্ড বই
            </h2>
            <p class="section-sub">আমাদের বিশেষভাবে বাছাই করা প্রিমিয়াম সংগ্রহ</p>
            <div class="product-grid" id="homeFeatured"></div>
        </div>

        <div class="newsletter">
            <h3>নতুন বইয়ের আপডেট পান</h3>
            <p>নতুন বই ও বিশেষ অফার সম্পর্কে সবার আগে জানতে সাবস্ক্রাইব করুন</p>
            <div class="newsletter-form">
                <input type="email" id="nlEmail" placeholder="আপনার ইমেইল লিখুন">
                <button onclick="subscribeNewsletter()">সাবস্ক্রাইব করুন</button>
            </div>
        </div>
    </div>
</div>
