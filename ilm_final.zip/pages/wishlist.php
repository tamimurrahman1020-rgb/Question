<div id="page-wishlist" class="page">
    <div class="page-header">
        <h1>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            Wishlist
        </h1>
        <p>আপনার পছন্দের বইসমূহ</p>
    </div>
    <div class="container" style="padding:1rem">
        <div class="product-grid" id="wishlistDisplay"></div>
    </div>
</div>
