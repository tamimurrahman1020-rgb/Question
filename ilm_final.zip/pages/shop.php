<div id="page-shop" class="page">
    <main class="container">
        <div class="shop-controls">
            <div class="controls-wrap">
                <div class="categories" id="catList">
                    <button class="cat-btn active" onclick="filterCat('All',this)">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
                        সব বই
                    </button>
                    <button class="cat-btn" onclick="filterCat('Quran',this)">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
                        Quran
                    </button>
                    <button class="cat-btn" onclick="filterCat('Hadith',this)">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        Hadith
                    </button>
                    <button class="cat-btn" onclick="filterCat('Dua',this)">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/></svg>
                        Dua
                    </button>
                    <button class="cat-btn" onclick="filterCat('Stories',this)">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/></svg>
                        Stories
                    </button>
                    <button class="cat-btn" onclick="filterCat('Fiqh',this)">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/></svg>
                        Fiqh
                    </button>
                    <button class="cat-btn" onclick="filterCat('Seerah',this)">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="9" width="20" height="13" rx="1"/><path d="M2 9a10 10 0 0 1 20 0"/><line x1="12" y1="4" x2="12" y2="9"/><line x1="7" y1="22" x2="7" y2="9"/><line x1="17" y1="22" x2="17" y2="9"/></svg>
                        Seerah
                    </button>
                </div>
                <div class="sort-row">
                    <p class="result-count"><span id="resultCount">0</span> টি বই পাওয়া গেছে</p>
                    <select id="priceSort" onchange="sortProducts()">
                        <option value="default">ডিফল্ট</option>
                        <option value="low">মূল্য: কম থেকে বেশি</option>
                        <option value="high">মূল্য: বেশি থেকে কম</option>
                        <option value="rating">রেটিং অনুযায়ী</option>
                        <option value="new">নতুন আগে</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="product-grid" id="productDisplay"></div>
        <div class="load-more-wrap" id="loadMoreWrap" style="display:none">
            <button class="btn-load-more" onclick="loadMore()">আরো বই দেখুন</button>
        </div>
    </main>
</div>
