<div id="page-about" class="page">
    <div class="page-header">
        <h1>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            আমাদের সম্পর্কে
        </h1>
        <p>ইসলামি জ্ঞানের আলো সবার কাছে পৌঁছে দেওয়াই আমাদের লক্ষ্য</p>
    </div>
    <div class="container">
        <section class="about-section">
            <div class="about-text">
                <h2>IlmLibrary এর গল্প</h2>
                <p>২০১৫ সালে একটি ছোট্ট স্বপ্ন নিয়ে যাত্রা শুরু হয়েছিল IlmLibrary এর। আমাদের লক্ষ্য ছিল বাংলাদেশের মুসলিম পাঠকদের কাছে মানসম্পন্ন ও বিশুদ্ধ ইসলামি বই সহজলভ্য করে তোলা।</p>
                <p>আজ আমরা গর্বিত যে আমাদের সংগ্রহে রয়েছে কোরআন, হাদিস, দোয়া, ইসলামিক গল্প, ফিকহ এবং সিরাহ সহ বিভিন্ন বিষয়ের শত শত বই।</p>
            </div>
            <div class="about-features">
                <div class="feature-card">
                    <div class="feature-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
                    <h3>১০০% বিশ্বস্ত</h3>
                    <p>প্রামাণ্য ও বিশ্বস্ত সূত্র থেকে সংগ্রহ করা বই বিক্রি করি।</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg></div>
                    <h3>দ্রুত ডেলিভারি</h3>
                    <p>সারাদেশে দ্রুত এবং নিরাপদ ডেলিভারি নিশ্চিত করা হয়।</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div>
                    <h3>সেরা মূল্য</h3>
                    <p>প্রতিটি বইয়ের সঠিক মূল্য নির্ধারণ করা হয়।</p>
                </div>
            </div>

            <div style="margin-top:2.5rem;text-align:center">
                <h2 class="section-title" style="justify-content:center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    আমাদের টিম
                </h2>
                <p class="section-sub">যারা আপনার সেবায় সর্বদা নিবেদিত</p>
                <div class="team-grid">
                    <div class="team-card"><div class="team-avatar">আ</div><h4>আব্দুল্লাহ</h4><p>Founder &amp; CEO</p></div>
                    <div class="team-card"><div class="team-avatar">উ</div><h4>উসামা</h4><p>Head of Operations</p></div>
                    <div class="team-card"><div class="team-avatar">ফ</div><h4>ফাতিমা</h4><p>Customer Support</p></div>
                    <div class="team-card"><div class="team-avatar">ই</div><h4>ইব্রাহিম</h4><p>Logistics</p></div>
                </div>
            </div>
        </section>

        <div class="faq-section">
            <h2 class="section-title">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                সচরাচর জিজ্ঞাসা (FAQ)
            </h2>
            <p class="section-sub">আপনার মনের প্রশ্নের উত্তর</p>
            <div id="faqList"></div>
        </div>
    </div>
</div>
