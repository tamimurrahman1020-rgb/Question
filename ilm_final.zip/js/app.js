// ══════════════════════════════════════════════
//  IlmLibrary — Main Application JS
//  Firebase config ও constants index.php থেকে inject হয়
//  Routing: ?page=xxx&id=xxx (hash-free — WhatsApp/FB safe)
// ══════════════════════════════════════════════

// ── State ─────────────────────────────────────
let products         = [];
let storeSettings    = { whatsapp: DEFAULT_WHATSAPP };
let cart             = JSON.parse(localStorage.getItem('ilm_cart')) || [];
let wishlist         = JSON.parse(localStorage.getItem('ilm_wish')) || [];
let activeCategory   = 'All';
let activeCoupon     = null;
let coupons          = {};
let displayLimit     = ITEMS_PER_PAGE;
let filteredProducts = [];
let pendingProductId = null;

// ── SVG Snippets ──────────────────────────────
const SVG_CHECK        = '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>';
const SVG_X            = '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>';
const SVG_CHECK_CIRCLE = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>';
const SVG_MSG          = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
const SVG_LIST         = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>';

// ── FAQ Data ──────────────────────────────────
const faqs = [
    { q: 'কিভাবে অর্ডার করবো?',      a: 'বই পছন্দ করে "Add to Cart" বাটনে ক্লিক করুন অথবা "WhatsApp" বাটনে ক্লিক করে সরাসরি আমাদের সাথে যোগাযোগ করুন।' },
    { q: 'ডেলিভারি কতদিনে হয়?',       a: 'ঢাকার মধ্যে ১-২ দিন এবং ঢাকার বাইরে ৩-৫ কার্যদিবসের মধ্যে ডেলিভারি দেওয়া হয়।' },
    { q: 'ডেলিভারি চার্জ কত?',         a: 'সারাদেশে ফ্ল্যাট ডেলিভারি চার্জ মাত্র ৮০ টাকা।' },
    { q: 'রিটার্ন পলিসি কী?',           a: 'বই পাওয়ার ৭ দিনের মধ্যে ক্ষতিগ্রস্ত বা ভুল বই হলে ফেরত দেওয়া যাবে।' },
    { q: 'কুপন কোড কোথায় পাবো?',      a: 'আমাদের Facebook পেজ ও WhatsApp গ্রুপে নিয়মিত কুপন কোড শেয়ার করা হয়।' }
];

// ── URL Helpers ───────────────────────────────
function getUrlParams() {
    const p = new URLSearchParams(window.location.search);
    return { page: p.get('page') || 'home', id: p.get('id') || '' };
}

// ── Visitor Tracking ──────────────────────────
(function trackVisit() {
    const today   = new Date();
    const dateKey = today.toISOString().slice(0, 10);
    const hourKey = today.getHours();
    const stKey   = 'ilm_visited_' + dateKey;
    if (localStorage.getItem(stKey)) return;
    Object.keys(localStorage).forEach(k => {
        if (k.startsWith('ilm_visited_') && k !== stKey) localStorage.removeItem(k);
    });
    localStorage.setItem(stKey, '1');
    db.ref('visits/' + dateKey).transaction(data => {
        if (!data) return { count: 1, hours: { [hourKey]: 1 } };
        data.count = (data.count || 0) + 1;
        if (!data.hours) data.hours = {};
        data.hours[hourKey] = (data.hours[hourKey] || 0) + 1;
        return data;
    });
})();

// ── INIT ──────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
    initFAQ();

    // সাথে সাথে সঠিক পেজ দেখাও (Firebase লোডের আগেই)
    const { page: startPage, id: startId } = getUrlParams();
    const shopPages = ['product', 'shop'];
    showPage(shopPages.includes(startPage) ? 'shop' : startPage, false);

    // Product link থেকে এলে pendingProductId সেট করো — একবারই খুলবে
    if (startPage === 'product' && startId) {
        pendingProductId = startId;
    }

    db.ref('products').on('value', snap => {
        const data = snap.val();
        products = data ? Object.keys(data).map(k => ({ id: k, ...data[k] })) : [];
        document.getElementById('statBooks').textContent = products.length + '+';
        filteredProducts = [...products];
        renderProducts(filteredProducts);
        renderHomeFeatured();
        // pendingProductId থাকলে এবং products লোড হলে modal খোলো (একবারই)
        if (pendingProductId && products.length) {
            const idToOpen = pendingProductId;
            pendingProductId = null;
            openModal(idToOpen);
        }
    });

    db.ref('settings').on('value', snap => {
        const d = snap.val();
        if (!d) return;
        storeSettings = d;
        document.getElementById('contactPhone').textContent = d.whatsapp || 'N/A';
        const waNum = d.whatsapp || DEFAULT_WHATSAPP;
        document.getElementById('floatWA').href      = `https://wa.me/88${waNum}?text=Assalamu Alaikum`;
        document.getElementById('waContactBtn').href = `https://wa.me/88${waNum}?text=Assalamu Alaikum, আমার একটি প্রশ্ন আছে।`;
        if (d.announcement && d.announcementActive) {
            document.getElementById('annText').textContent = d.announcement;
            document.getElementById('announcementBar').classList.add('show');
        }
    });

    db.ref('coupons').on('value', snap => { coupons = snap.val() || {}; });

    updateCartUI();
    updateWishUI();

    // Browser Back/Forward button
    window.addEventListener('popstate', () => {
        const { page, id } = getUrlParams();
        if (page === 'product' && id) {
            showPage('shop', false);
            if (products.length) openModal(id);
            else pendingProductId = id;
        } else {
            closeModalSilent();
            showPage(page, false);
        }
    });

    // Nav link click interceptor — full page reload হবে না, SPA navigation
    document.addEventListener('click', e => {
        const link = e.target.closest('[data-page]');
        if (link) {
            e.preventDefault();
            const pg = link.getAttribute('data-page');
            navigateTo(pg);
            document.getElementById('mobileMenu').classList.remove('open');
        }
    });

    window.addEventListener('scroll', () => {
        document.getElementById('backTop').classList.toggle('visible', window.scrollY > 400);
    });
});

// ── NAVIGATION ────────────────────────────────
/**
 * navigateTo(page, id)
 * URL: ?page=shop | ?page=product&id=abc123
 * এই format WhatsApp, Messenger, Facebook — সবখানে কাজ করে।
 * Hash (#) কখনো ব্যবহার করা হয় না।
 */
function navigateTo(page, id) {
    let url = window.location.pathname + '?page=' + page;
    if (id) url += '&id=' + encodeURIComponent(id);

    if (id) {
        history.pushState({ page, id }, '', url);
        showPage('shop', false);
        if (products.length) openModal(id);
        else pendingProductId = id;
    } else {
        closeModalSilent();
        history.pushState({ page }, '', url);
        showPage(page, true);
    }
}

function showPage(name, animate) {
    const valid  = ['home', 'shop', 'about', 'contact', 'wishlist'];
    const target = valid.includes(name) ? name : 'home';

    function applyPage() {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        const el = document.getElementById('page-' + target);
        if (el) el.classList.add('active');

        document.querySelectorAll('.nav-link,.mobile-nav-link').forEach(l => {
            l.classList.remove('active');
            if ((l.getAttribute('data-page') || '') === target) l.classList.add('active');
        });

        window.scrollTo({ top: 0, behavior: 'smooth' });
        if (target === 'wishlist') renderWishlist();
        if (animate) document.getElementById('pageLoader').classList.remove('active');
    }

    if (animate) {
        document.getElementById('pageLoader').classList.add('active');
        setTimeout(applyPage, 300);
    } else {
        // animate না থাকলে সাথে সাথেই page দেখাও — async race condition নেই
        applyPage();
    }
}

function navToWishlist() { navigateTo('wishlist'); }
function toggleMobile()  { document.getElementById('mobileMenu').classList.toggle('open'); }

// ── FAQ ───────────────────────────────────────
function initFAQ() {
    const container = document.getElementById('faqList');
    if (!container) return;
    faqs.forEach((f, i) => {
        container.innerHTML += `<div class="faq-item">
            <button class="faq-q" onclick="toggleFaq(${i},this)">${f.q}
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
            <div class="faq-a" id="faq-${i}"><p>${f.a}</p></div>
        </div>`;
    });
}

function toggleFaq(i, btn) {
    document.getElementById('faq-' + i).classList.toggle('open');
    btn.classList.toggle('open');
}

// ── SEARCH ────────────────────────────────────
function handleSearch() {
    const dq    = document.getElementById('desktopSearch')?.value || '';
    const mq    = document.getElementById('mobileSearch')?.value || '';
    const query = (dq || mq).toLowerCase();
    const suggs = ['desktopSugg', 'mobileSugg'];

    if (!query) {
        suggs.forEach(sid => { const el = document.getElementById(sid); if(el){ el.innerHTML=''; el.classList.remove('active'); } });
        return;
    }

    const matched = products.filter(p =>
        p.title.toLowerCase().includes(query) || (p.category || '').toLowerCase().includes(query)
    ).slice(0, 6);

    const html = matched.length
        ? matched.map(p => `<div class="sugg-item" onclick="navigateTo('product','${p.id}')">
            <img src="${getMainImg(p)}" alt="${p.title}">
            <div class="sugg-info"><h4>${p.title}</h4><span>${p.category}</span></div>
          </div>`).join('')
        : '<p class="no-result">কোনো বই পাওয়া যায়নি।</p>';

    suggs.forEach(sid => { const el = document.getElementById(sid); if(el){ el.innerHTML=html; el.classList.add('active'); } });
}

document.addEventListener('click', e => {
    if (!e.target.closest('.search-bar') && !e.target.closest('.mobile-search')) {
        document.querySelectorAll('.search-sugg').forEach(el => { el.innerHTML = ''; el.classList.remove('active'); });
    }
});

// ── PRODUCTS ──────────────────────────────────
function getMainImg(p) {
    return (p.images && p.images.length) ? p.images[0] : (p.img || 'https://via.placeholder.com/150x200?text=No+Image');
}

function stars(rating) {
    return Array.from({ length: 5 }, (_, i) =>
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="${i < rating ? '' : 'empty'}" stroke="currentColor" stroke-width="2" fill="${i < rating ? 'currentColor' : 'none'}"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`
    ).join('');
}

function renderProducts(items, limit) {
    const display = document.getElementById('productDisplay');
    const lim     = limit || ITEMS_PER_PAGE;
    const showing = items.slice(0, lim);
    document.getElementById('resultCount').textContent = items.length;

    if (!items.length) {
        display.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:3rem">কোনো বই পাওয়া যায়নি।</p>';
        document.getElementById('loadMoreWrap').style.display = 'none';
        return;
    }
    display.innerHTML = '';
    showing.forEach(p => display.appendChild(buildCard(p)));
    document.getElementById('loadMoreWrap').style.display = items.length > lim ? 'block' : 'none';
}

function buildCard(p) {
    const mainImg  = getMainImg(p);
    const disc     = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
    const isWished = wishlist.includes(p.id);
    const inStock  = p.inStock !== false;
    const badge    = p.badge || (disc >= 10 ? 'sale' : '');

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.textContent = JSON.stringify({
        '@context': 'https://schema.org', '@type': 'Book',
        'name': p.title, 'image': mainImg,
        'description': p.description || p.title,
        'genre': p.category || 'Islamic', 'inLanguage': 'bn',
        'offers': { '@type': 'Offer', 'price': p.price, 'priceCurrency': 'BDT',
            'availability': inStock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock' }
    });

    const card = document.createElement('div');
    card.className = 'product-card' + (!inStock ? ' out-of-stock' : '');
    card.setAttribute('itemscope', '');
    card.setAttribute('itemtype', 'https://schema.org/Book');
    card.appendChild(schemaScript);
    card.innerHTML += `
        <div class="product-img">
            ${badge ? `<span class="p-badge badge-${badge}">${badge === 'sale' ? `-${disc}%` : badge.toUpperCase()}</span>` : ''}
            ${!inStock ? '<span class="p-badge badge-outstock" style="left:auto;right:10px">আউট অফ স্টক</span>' : ''}
            <button class="copy-link-btn" onclick="event.stopPropagation();copyLink('${p.id}')" title="Copy Link">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
            </button>
            <button class="wishlist-btn${isWished ? ' active' : ''}" onclick="event.stopPropagation();toggleWish('${p.id}',this)">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="${isWished ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            </button>
            <img src="${mainImg}" alt="${p.title} - ইসলামি বই | IlmLibrary" onclick="navigateTo('product','${p.id}')" loading="lazy" itemprop="image">
        </div>
        <div class="p-info">
            <span class="p-cat">${p.category}</span>
            <h3 class="p-title" itemprop="name">${p.title}</h3>
            <div class="p-rating">${stars(p.rating || 5)}</div>
            <div class="p-price-row">
                <span class="p-price">Tk ${p.price.toLocaleString()}</span>
                ${p.oldPrice ? `<span class="p-old">Tk ${p.oldPrice}</span>` : ''}
                ${disc >= 5 ? `<span class="p-disc">-${disc}%</span>` : ''}
            </div>
            <button class="btn-add${!inStock ? ' disabled' : ''}" onclick="${inStock ? `addToCart('${p.id}')` : ''}" ${!inStock ? 'disabled' : ''}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
                ${inStock ? 'Add to Cart' : 'স্টক নেই'}
            </button>
        </div>`;
    return card;
}

function renderHomeFeatured() {
    const feat = products.filter(p => p.featured);
    const sec  = document.getElementById('homeFeaturedSection');
    const grid = document.getElementById('homeFeatured');
    if (!feat.length) { sec.style.display = 'none'; return; }
    sec.style.display = 'block';
    grid.innerHTML = '';
    feat.slice(0, 4).forEach(p => grid.appendChild(buildCard(p)));
}

function filterCat(cat, btn) {
    activeCategory = cat;
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    displayLimit = ITEMS_PER_PAGE;
    applyFilters('');
}

function applyFilters(query) {
    const q = query !== undefined ? query : (document.getElementById('desktopSearch')?.value || '').toLowerCase();
    let f = [...products];
    if (activeCategory !== 'All') f = f.filter(p => p.category === activeCategory);
    if (q) f = f.filter(p => p.title.toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q));
    filteredProducts = f;
    renderProducts(f, displayLimit);
}

function sortProducts() {
    const v = document.getElementById('priceSort').value;
    let sorted = [...filteredProducts];
    if      (v === 'low')    sorted.sort((a, b) => a.price - b.price);
    else if (v === 'high')   sorted.sort((a, b) => b.price - a.price);
    else if (v === 'rating') sorted.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    else if (v === 'new')    sorted = sorted.filter(p => p.badge === 'new').concat(sorted.filter(p => p.badge !== 'new'));
    renderProducts(sorted, displayLimit);
}

function loadMore() {
    displayLimit += ITEMS_PER_PAGE;
    renderProducts(filteredProducts, displayLimit);
}

// ── WISHLIST ──────────────────────────────────
function toggleWish(id, btn) {
    const idx = wishlist.indexOf(id);
    const svg = btn.querySelector('svg');
    if (idx > -1) { wishlist.splice(idx, 1); btn.classList.remove('active'); svg.setAttribute('fill', 'none'); showToast('Wishlist থেকে সরানো হয়েছে'); }
    else          { wishlist.push(id); btn.classList.add('active'); svg.setAttribute('fill', 'currentColor'); showToast('Wishlist এ যোগ হয়েছে'); }
    localStorage.setItem('ilm_wish', JSON.stringify(wishlist));
    updateWishUI();
}
function updateWishUI() { document.getElementById('wishBadge').textContent = wishlist.length; }
function renderWishlist() {
    const grid   = document.getElementById('wishlistDisplay');
    const wished = products.filter(p => wishlist.includes(p.id));
    if (!wished.length) { grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:3rem">কোনো বই Wishlist এ নেই।</p>'; return; }
    grid.innerHTML = '';
    wished.forEach(p => grid.appendChild(buildCard(p)));
}

// ── CART ──────────────────────────────────────
function toggleCart() { document.getElementById('cartSidebar').classList.toggle('active'); }

function addToCart(id) {
    const p = products.find(x => x.id === id);
    if (!p || p.inStock === false) return;
    const ex = cart.find(x => x.id === id);
    if (ex) ex.qty++;
    else cart.push({ id: p.id, title: p.title, price: p.price, img: getMainImg(p), qty: 1 });
    updateCartUI();
    showToast('Cart এ যোগ হয়েছে!');
}

function updateQty(id, d) {
    const item = cart.find(x => x.id === id);
    if (item) { item.qty += d; if (item.qty <= 0) removeFromCart(id); else updateCartUI(); }
}

function removeFromCart(id) {
    cart = cart.filter(x => x.id !== id);
    if (activeCoupon) validateCouponAmount();
    updateCartUI();
}

function updateCartUI() {
    localStorage.setItem('ilm_cart', JSON.stringify(cart));
    const list  = document.getElementById('cartListUI');
    const badge = document.getElementById('cartBadge');
    badge.textContent = cart.reduce((a, x) => a + x.qty, 0);

    if (!cart.length) {
        list.innerHTML = `<div class="cart-empty">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
            <p>Cart খালি</p></div>`;
        document.getElementById('cartSubtotal').textContent   = 'Tk 0';
        document.getElementById('cartTotal').textContent      = 'Tk ' + DELIVERY_CHARGE;
        document.getElementById('discountRow').style.display  = 'none';
        document.getElementById('deliveryCharge').textContent = 'Tk ' + DELIVERY_CHARGE;
        return;
    }

    let subtotal = 0;
    list.innerHTML = '';
    cart.forEach(item => {
        subtotal += item.price * item.qty;
        list.innerHTML += `<div class="cart-item">
            <img src="${item.img}" alt="${item.title}">
            <div class="cart-item-info">
                <p class="cart-item-title">${item.title}</p>
                <p class="cart-item-price">Tk ${item.price.toLocaleString()}</p>
                <div class="cart-item-qty">
                    <button class="qty-btn" onclick="updateQty('${item.id}',-1)">−</button>
                    <span>${item.qty}</span>
                    <button class="qty-btn" onclick="updateQty('${item.id}',1)">+</button>
                </div>
            </div>
            <button class="cart-item-remove" onclick="removeFromCart('${item.id}')">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
            </button>
        </div>`;
    });

    let discount = 0;
    if (activeCoupon) {
        discount = activeCoupon.type === 'percent'
            ? Math.round(subtotal * activeCoupon.discount / 100)
            : activeCoupon.discount;
        document.getElementById('discountRow').style.display = 'flex';
        document.getElementById('discountAmt').textContent   = '-Tk ' + discount;
    } else {
        document.getElementById('discountRow').style.display = 'none';
    }

    const total = subtotal - discount + DELIVERY_CHARGE;
    document.getElementById('cartSubtotal').textContent   = 'Tk ' + subtotal.toLocaleString();
    document.getElementById('deliveryCharge').textContent = 'Tk ' + DELIVERY_CHARGE;
    document.getElementById('cartTotal').textContent      = 'Tk ' + total.toLocaleString();
}

// ── COUPON ────────────────────────────────────
function applyCoupon() {
    const code   = document.getElementById('couponInput').value.trim().toUpperCase();
    if (!code) return;
    const coupon = coupons[code];
    if (coupon && coupon.active) {
        const sub = cart.reduce((a, i) => a + i.price * i.qty, 0);
        if (coupon.minOrder && sub < coupon.minOrder) {
            document.getElementById('couponMsg').innerHTML = `<p style="font-size:.78rem;color:var(--danger);padding:0 .25rem;display:flex;align-items:center;gap:5px">${SVG_X} ন্যূনতম অর্ডার Tk ${coupon.minOrder} হতে হবে।</p>`;
            return;
        }
        activeCoupon = coupon;
        document.getElementById('couponInput').disabled = true;
        document.getElementById('couponMsg').innerHTML  = `<p style="font-size:.78rem;color:var(--success);padding:0 .25rem;display:flex;align-items:center;gap:5px">${SVG_CHECK_CIRCLE} কুপন সফলভাবে প্রয়োগ হয়েছে!</p>`;
        updateCartUI();
    } else {
        document.getElementById('couponMsg').innerHTML = `<p style="font-size:.78rem;color:var(--danger);padding:0 .25rem;display:flex;align-items:center;gap:5px">${SVG_X} কুপন কোডটি বৈধ নয়।</p>`;
    }
}

function removeCoupon() {
    activeCoupon = null;
    document.getElementById('couponInput').value    = '';
    document.getElementById('couponInput').disabled = false;
    document.getElementById('couponMsg').innerHTML  = '';
    updateCartUI();
}

function checkoutWA() {
    if (!cart.length) return showToast('Cart খালি!');
    const num = storeSettings.whatsapp || DEFAULT_WHATSAPP;
    const sub = cart.reduce((a, i) => a + i.price * i.qty, 0);
    let discount = 0;
    let msg = 'Assalamu Alaikum, IlmLibrary থেকে অর্ডার:%0A%0A';
    cart.forEach(i => { msg += `• ${i.title} (×${i.qty}) = Tk ${(i.price * i.qty).toLocaleString()}%0A`; });
    if (activeCoupon) {
        discount = activeCoupon.type === 'percent' ? Math.round(sub * activeCoupon.discount / 100) : activeCoupon.discount;
        msg += `%0A Discount: -Tk ${discount}%0A`;
    }
    msg += `%0A 🚚 Delivery: Tk ${DELIVERY_CHARGE}%0A`;
    msg += `*Total: Tk ${(sub - discount + DELIVERY_CHARGE).toLocaleString()}*`;
    window.open(`https://wa.me/88${num}?text=${msg}`, '_blank');
}

// ── MODAL ─────────────────────────────────────
function openModal(id) {
    const p = products.find(x => x.id === id);
    if (!p) return;
    const modal    = document.getElementById('pModal');
    const body     = document.getElementById('modalBody');
    const images   = (p.images && p.images.length) ? p.images : [p.img || ''];
    const inStock  = p.inStock !== false;
    const disc     = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
    const specRows = Object.entries(p.specs || {}).map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join('');
    const reviews  = p.reviews ? Object.values(p.reviews) : [];
    const reviewsHtml = reviews.length
        ? reviews.map(r => `<div class="review-item"><div class="review-header"><span class="review-name">${r.name || 'Anonymous'}</span><div class="review-stars">${stars(r.rating || 5)}</div></div><p class="review-text">${r.text || ''}</p></div>`).join('')
        : '<p class="no-reviews">এখনো কোনো রিভিউ নেই।</p>';
    const thumbsHtml = images.length > 1
        ? `<div class="gallery-thumbs">${images.map((img, i) => `<img src="${img}" class="thumb${i === 0 ? ' active' : ''}" onclick="changeImg(this,'${img}')">`).join('')}</div>` : '';

    // URL আপডেট করো — এই URL সব জায়গায় কাজ করে
    history.replaceState({ page: 'product', id }, '', window.location.pathname + '?page=product&id=' + encodeURIComponent(id));

    body.innerHTML = `
        <button class="close-modal" onclick="closeModal()"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>
        <div class="modal-gallery">
            <img id="modalMainImg" src="${images[0]}" alt="${p.title}" class="modal-main-img">
            ${thumbsHtml}
        </div>
        <div class="modal-body">
            <span class="modal-cat">${p.category}</span>
            <h2 class="modal-title">${p.title}</h2>
            <div class="modal-meta">
                <div class="modal-rating">${stars(p.rating || 5)}<span>(${(p.rating || 5).toFixed(1)} · ${reviews.length} reviews)</span></div>
                <span class="modal-stock ${inStock ? 'in-stock' : 'out-stock'}">${inStock ? SVG_CHECK + ' স্টকে আছে' : SVG_X + ' স্টক নেই'}</span>
            </div>
            <div class="delivery-badge"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>সারাদেশে ডেলিভারি চার্জ মাত্র Tk ${DELIVERY_CHARGE}</div>
            <div class="modal-desc-box">
                <h4 class="modal-desc-title"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>বিবরণ</h4>
                <p class="modal-desc-text">${p.description || 'এই বইয়ের বিস্তারিত বিবরণ শীঘ্রই আপডেট করা হবে।'}</p>
            </div>
            ${specRows ? `<div class="modal-specs"><h4 class="modal-desc-title" style="margin-bottom:.5rem">${SVG_LIST} বিস্তারিত তথ্য</h4><table>${specRows}</table></div>` : ''}
            <div class="modal-price">Tk ${p.price.toLocaleString()}${p.oldPrice ? ` <small>Tk ${p.oldPrice}</small>` : ''}${disc >= 5 ? ` <span class="p-disc" style="font-size:.85rem">-${disc}%</span>` : ''}</div>
            <div class="modal-actions">
                <button class="btn-add${!inStock ? ' disabled' : ''}" style="padding:13px;font-size:.9rem" onclick="addToCart('${p.id}')" ${!inStock ? 'disabled' : ''}>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
                    ${inStock ? 'Cart এ যোগ করুন' : 'স্টক নেই'}
                </button>
                <button class="btn-wa" style="padding:13px;font-size:.9rem" onclick="directWA('${p.title.replace(/'/g, "\\'")}')">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="16" height="16"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    WhatsApp এ অর্ডার করুন
                </button>
                <div class="modal-share-row">
                    <button class="btn-share" onclick="copyLink('${p.id}')"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>লিংক কপি</button>
                    <button class="btn-share" onclick="shareToFB('${p.id}')"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>Facebook</button>
                    <button class="btn-share" onclick="shareToWA('${p.title.replace(/'/g, "\\'")}','${p.id}')"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>Share</button>
                </div>
            </div>
            <div class="modal-reviews">
                <h4>${SVG_MSG} পাঠকদের মতামত (${reviews.length})</h4>
                ${reviewsHtml}
            </div>
        </div>`;

    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function changeImg(el, src) {
    document.getElementById('modalMainImg').src = src;
    document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
}

function closeModal() {
    document.getElementById('pModal').style.display = 'none';
    document.body.style.overflow = '';
    history.replaceState({ page: 'shop' }, '', window.location.pathname + '?page=shop');
    showPage('shop', false);
}

function closeModalSilent() {
    document.getElementById('pModal').style.display = 'none';
    document.body.style.overflow = '';
}

// ── SHARE — সব platform এ কাজ করে ───────────
// ?page=product&id=XXX — hash (#) নেই, কোনো app কখনো strip করে না
function getProductUrl(id) {
    const base = location.href.split('?')[0].split('#')[0];
    return base + '?page=product&id=' + encodeURIComponent(id);
}
function copyLink(id) {
    navigator.clipboard.writeText(getProductUrl(id)).then(() => showToast('লিংক কপি হয়েছে!'));
}
function shareToFB(id) {
    window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(getProductUrl(id)), '_blank');
}
function shareToWA(title, id) {
    const text = 'দেখুন এই বইটি: ' + title + '\n' + getProductUrl(id);
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank');
}
function directWA(title) {
    const num = storeSettings.whatsapp || DEFAULT_WHATSAPP;
    window.open(`https://wa.me/88${num}?text=${encodeURIComponent('Assalamu Alaikum, আমি এই বইটি অর্ডার করতে চাই: ' + title)}`, '_blank');
}

// ── NEWSLETTER & CONTACT ──────────────────────
function subscribeNewsletter() {
    const em = document.getElementById('nlEmail').value;
    if (!em) return;
    db.ref('subscribers').push({ email: em, date: new Date().toISOString() });
    document.getElementById('nlEmail').value = '';
    showToast('সফলভাবে সাবস্ক্রাইব হয়েছে!');
}

function handleContact(e) {
    e.preventDefault();
    showToast('মেসেজ পাঠানো হয়েছে! আমরা শীঘ্রই যোগাযোগ করবো।');
    e.target.reset();
}

// ── TOAST ─────────────────────────────────────
function showToast(msg) {
    document.getElementById('toastTxt').textContent = msg;
    const t = document.getElementById('toast');
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3500);
}
